﻿using System;
using System.Collections.Generic;
using Xamarin.Forms;

namespace test
{
    public partial class MyView : ContentView
    {
        public MyView()
        {
            InitializeComponent();
        }

        public ContentView GetView(View view)
        {
            var presenter = new ContentPresenter();
           var layout = this.FindByName<Grid>("controlLayout");
            layout.Children.Add(presenter,1,1);
            Content = view;
            return this;
        }
    }
}
